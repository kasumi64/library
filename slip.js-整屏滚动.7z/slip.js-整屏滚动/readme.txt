http://binnng.github.io/slip.js/docs/
https://github.com/binnng/slip.js